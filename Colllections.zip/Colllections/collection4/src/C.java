/*Create an ArrayList that can store only numbers like int,float,double,etc, but not any other data type.*/
import java.util.ArrayList;
import java.util.ListIterator;

public class C {


		public static void main(String[] args) {
			// TODO Auto-generated method stub
			ArrayList<Number> al=new ArrayList<Number>();
			al.add(1);
			al.add(2);
			al.add(3);
			ListIterator i=al.listIterator();


	while(i.hasNext())
	{
		System.out.println(i.next());
	}
	while(i.hasPrevious())
	{
		System.out.println(i.previous());
	}
	al.add(0,4);
	System.out.println(al);
	
		}
}
