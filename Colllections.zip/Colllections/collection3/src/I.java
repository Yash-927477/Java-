/* Write a program to store integer numbers into Vector collection and use Enumeration to print the values. Also try using Iterator and ListIterator to print the values from the Vector object.*/
import java.util.*;

public class I {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Vector<Integer> v=new Vector<Integer>();
v.add(1);
v.add(2);
Enumeration e=v.elements();
while(e.hasMoreElements())
{
	System.out.println(e.nextElement());
}
}

}
