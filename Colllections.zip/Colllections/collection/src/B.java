/*	
 Create an ArrayList that can store only Strings. 
Create a printAll method that will print all the elements of the ArrayList using an Iterator and obeserve the order of the values being printed.*/


import java.util.ArrayList;
import java.util.ListIterator;
public class B {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> al=new ArrayList<String>();
		al.add("a");
		al.add("e");
		ListIterator i=al.listIterator();


while(i.hasNext())
{
	System.out.println(i.next());
}
	}

}
