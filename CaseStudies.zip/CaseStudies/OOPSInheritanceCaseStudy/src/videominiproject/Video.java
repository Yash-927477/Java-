package videominiproject;

public class Video {
String video;
boolean checkout;
int rating;
Video()
{
	
}
Video(String video)
{
	this.video=video;
}
public String getName(String video)
{
	return video;
}
public void doCheckout()
{
 checkout=true;
}
public void doReturn(String name)
{
	checkout=false;
}
public void receiveRating(int orating)
{
rating=orating;	
}
public int getRating()
{

	return rating;
}
public boolean checkout()
{
	return checkout;
}
public String getVideo() {
	return video;
}



}
