package videominiproject;

public class Videostore extends Video{
Video[] store= new Video[5];
int vc=0;
//String videoname;
public void addVideo(String name)
{
	store[vc]=new Video(name);

	vc++;
}
public void docheckout(String name)
{
	for(int i=0;i<vc;i++ )
	{
		if(store[i].video.equals(name))
		{
			store[i].doCheckout();
		}
		else
			System.out.println("video incorrect");
	}
	
}
public void doreturn(String name)
{
	for(int i=0;i<vc;i++ )
	{
		if(store[i].video.equals(name))	
			{
			store[i].doReturn(name);
			}
		else
			System.out.println("video incorrect");
	}
}
public void receiverating(String name,int rating)
{
	for(int i=0;i<vc;i++)
	{
	if(name.equals(store[i].video))
	{
	store[i].receiveRating(rating);
	}
	else
	System.out.println("enter correct");
	}
}
	public int GetRating(String ghj)
	{
		int r;
	
		for(int i=0;i<vc;i++)
		{
			if(ghj.equals(store[i].getVideo()))
		}
		r=store[i].getRating();
	}

}
