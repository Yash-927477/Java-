package videominiproject;

import java.util.Scanner;

public class Mainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Videostore vs=new Videostore();
		int option,vrating;
		String vname;
System.out.println("MAIN MENU");
System.out.println("1.Add Videos");
System.out.println("2.Checkout Video");
System.out.println("3.Return Video");
System.out.println("4.Receive Rating");
System.out.println("5.List Inventory");
//System.out.println("Exit");
while(true)
{
Scanner sc=new Scanner(System.in);
option=sc.nextInt(); 
switch(option)
{
case 1 : System.out.println("enter the name");
         vname=sc.next();
         vs.addVideo(vname);
         break;
case 2 : System.out.println("enter video name");
         vname=sc.next();
         vs.docheckout(vname);
         break;
case 3 : System.out.println("enter the video to return");
         vname=sc.next();
         vs.doreturn(vname);
         break;
case 4 : System.out.println("enter the video and ratring");
         vname=sc.next();
         vrating=sc.nextInt();
         vs.receiverating(vname,vrating);
         break;
         
case 5:
	    for(int i=0;i<vs.vc;i++)
	    {
	    System.out.println("VIDEONAME");
        //System.out.println(vs.GetVideo());
        System.out.println("checkout status");
       //System.out.println(vs.CheckOut());
        System.out.println("rating");
       System.out.println(vs.GetRating());
	    }
	    break;
case 6 :
	System.out.println("thank u for printing");
	System.exit(0);
	}

}
}
}

