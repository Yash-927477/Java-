
class Minipro
{
public static void main(String[] args)
{
int sal,da=0,basic,hra,it,index=-1;
String ch="",des="";
String[][] a={ {"1001","ashish","2009","e","r&d","20000","8000","3000"},
		{"1002","sushma","2012","c","pm","30000","12000","9000"},
		{"1003","rahul","2008","k","acct","10000","8000","1000"},
              {"1004","chahat","2015","r","front desk","6000","8000","2000"},
               {"1005","ranjan","2005","m","engg","50000","20000","20000"},
               {"1006","suman","2000","e","manufacturing","23000","9000","4400"},
              {"1007","tanmay","2006","c","pm","29000","12000","10000"}};

for(int i=0;i<7;i++)
{
if(args[0].equals(a[i][0]))
{
index = i;
ch=a[i][3];
switch(ch)
{
case "e" : da=20000;
           des="Engineer";
           break;
case "c" : da=32000;
           des="Consultant";
           break;
case "k" : da=12000;
           des="Clerk";
           break;
case "r" : da=15000;
           des="Receptionist";
           break;
case "m" : da=40000;
           des="Manager";
           break;
}
break;
}
}
if(index==-1)
{
System.out.println("invalid");
}
else
{
basic=Integer.parseInt(a[index][5]);
hra=Integer.parseInt(a[index][6]);
it=Integer.parseInt(a[index][7]);
sal=basic+hra+da-it;
System.out.println("EMPNO"+"	"+"EMPNAME"+"	"+"DEPT"+"	"+"DES"+"	"+"SALARY");
System.out.println(a[index][0]+"	"+a[index][1]+"		"+des+"		"+sal);
}
}
}	