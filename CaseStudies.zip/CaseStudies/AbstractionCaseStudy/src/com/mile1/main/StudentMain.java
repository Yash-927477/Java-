package com.mile1.main;
import  com.mile1.bean.*;
import com.mile1.exception.*;
import com.mile1.service.*;
public class StudentMain {
	static Student data[]=new Student[4];
	StudentMain()
	{
		for(int i=0;i<data.length;i++)
		{
			data[i]=new Student();
			
		}
		data[0]=new Student("sekar", new int[] {85,75,95});
		data[1]=new Student(null,new int[] {11,22,33});
		data[2]=null;
		data[3]=new Student("manoj",null);
	}
	public static void main(String[] args)
	{
		String val, grade,result;
		StudentMain sm=new StudentMain();
		StudentReport sr=new StudentReport();
		StudentService ss=new StudentService();
		for(int i=0;i<4;i++)
		{
			val=sr.Validate(sm.data[i]);
			if(val.equals("VALID")) {
				grade = sr.findGrades(sm.data[i]);
				sm.data[i].setGrade(grade);
				result=sm.data[i].getGrade();
				System.out.println(result);
			}
		}
		System.out.println(ss.findNumberOfNullMarksArray(sm.data));
		System.out.println(ss.findNumberOfNullName(sm.data));
		System.out.println(ss.findNumbrOfNullbjects(sm.data));
	

}
}
