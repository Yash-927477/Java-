package com.mile1.service;
import com.mile1.bean.*;
//import com.mile1.exception.*;

public class StudentService {
	
public int findNumberOfNullMarksArray(Student s[])
{
	int size,c=0;
	size=s.length;
	
	for(int i=0;i<size;i++)
	{
		if(s[i]==null)
		{
	
		System.out.println("null object");
		continue;
		}
		
		else if (s[i].getMarks()==null)
{
	c++;
}
		
}
	return c;
}
public int findNumberOfNullName(Student s[])
{
	int size,c=0;
	size=s.length;
	for(int i=0;i<size;i++)
	{
		if(s[i]==null)
		{
	
		System.out.println("null object");
		continue;
		}
		
		else if (s[i].getName()==null)
{
	c++;
}
}
return c;
}
public int findNumbrOfNullbjects(Student s[])
{
	int size,c=0;
	size=s.length;
	for(int i=0;i<size;i++)
	{
		if(s[i]==null)
			c++;
	}
	return c;
}
}