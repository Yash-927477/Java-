package com.mile1.service;

import com.mile1.bean.Student;
import com.mile1.exception.*;

public class StudentReport {



	public String findGrades(Student studentObject)
	{
		int n,sum=0;
		String grade;
		int a[];
		a=studentObject.getMarks();
		n=a.length;
		for(int i=0;i<n;i++)
		{
			if(a[i]<35)
			{
				grade="F";
				break;
			}
			sum=sum+a[i];
		}
		if(sum<150)
		{
			grade="C";
		}
		else if(sum<200)
		{
			grade="B";
		}
		else if(sum<250)
		{
			grade="A";
		}
		else
		{
			grade="A+";
		}
		return grade;}
		
 public String Validate(Student s) 
 {
	 if(s==null)
	 {
	 try
	 {
		 throw new NullStudentObjectException();
	 }
	 catch(NullStudentObjectException n)
	 {
		System.out.println(n.toString());
		return "Invalid";
	 }
	 
	 }
	 else
	 {
		 if(s.getName()==null)
		 {
	 try
	 {
		throw new NullNameException();
	 }
	 catch(NullNameException e)
	 {
		 System.out.println(e.toString());
		 return "Invalid";
	 }}
	 else if(s.getMarks()==null)
	 {
	 try
	 {
		 throw new NullMarksArrayException();
	 }
	 catch(NullMarksArrayException m)
	 {
    System.out.println(m.toString());
    return "Invalid";
    // return m.toString();
	}
	 }
	 
	 else
		 return "VALID";
 }
	 
 }
	 
 }

