package com.mile1.exception;

public class NullStudentObjectException extends Exception {


	private static final long serialVersionUID = 1L;

	public String toString() {
		return "object is null";
	}
}
