package com.wipro.candidate.util;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;


public class DBUtil {
public static Connection getDBConn() throws SQLException,ClassNotFoundException
{
	Connection con=null;
	Class.forName("oracle.jdbc.OracleDriver");
	con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","B8984020127281","B8984020127281");
	
	return con;
}
}
