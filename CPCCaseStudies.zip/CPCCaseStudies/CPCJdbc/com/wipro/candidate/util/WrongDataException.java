package com.wipro.candidate.util;

public class WrongDataException extends Exception{

	@Override
	public String toString() {
			//write code here
		return "Data Incorrect";
	}

}
 