package com.wipro.candidate.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.wipro.candidate.bean.CandidateBean;
import com.wipro.candidate.bean.CandidateBean;
import com.wipro.candidate.util.*;
import com.wipro.candidate.dao.CandidateDAO;;
   public class CandidateMain {

	/**
	 * @param args
	 */
	   
	   
	public String addCandidate(CandidateBean studBean) throws SQLException,ClassNotFoundException
	{
		CandidateDAO cd=new CandidateDAO();
		String result="";
		String i="";
		
	
		try
		{
	    if(studBean==null)
	    {
	    	
	    		throw new WrongDataException();
	    	
	    }	
	    
	    else if(studBean.getName()==null)
	    	{
	    	
	    		throw new WrongDataException();
	    
	    	}
	    else if(studBean.getName().equals(""))
    	{
    	
    		throw new WrongDataException();
    
    	}
	    else if(studBean.getName().length()<2)
	    	{
	    	
	    		throw new WrongDataException();
	    
	    	}
	    else if(studBean.getM1()<0 || studBean.getM1()>100) {
	    	
	    	
	    		throw new WrongDataException();
	    
	    	}
	    else if(studBean.getM2()<0 || studBean.getM2()>100) {
	    	
	    		throw new WrongDataException();
	    	
	    }
	    	
	    else if(studBean.getM3()<0 || studBean.getM3()>100)
	    {
	    	
	    		throw new WrongDataException();
	    	
	    }
	    else
	    {
	    	if(result.equals("")) 
			{
				 i=cd.generateCandidateId(studBean.getName());
				studBean.setId(i);
			}
			
		    	if((studBean.getM1()+studBean.getM2()+studBean.getM3())>=240)
		    	{
		    		studBean.setGrade("Distinction");
		    		studBean.setResult("PASS");
		    	}
		    	else if((studBean.getM1()+studBean.getM2()+studBean.getM3())>=180 && (studBean.getM1()+studBean.getM2()+studBean.getM3())<240)
		    	{
		    		studBean.setGrade("First Class");
		    		studBean.setResult("PASS");
		    	}
		    	else if((studBean.getM1()+studBean.getM2()+studBean.getM3())>=150 && (studBean.getM1()+studBean.getM2()+studBean.getM3())<180)
		    	{
		    		studBean.setGrade("Second Class");
		    		studBean.setResult("PASS");
		    	}
		    	else if((studBean.getM1()+studBean.getM2()+studBean.getM3())>=105 && (studBean.getM1()+studBean.getM2()+studBean.getM3())<150)
		    	{
		    		studBean.setGrade("Third Class");
		    		studBean.setResult("PASS");
		    	}
		    	else if((studBean.getM1()+studBean.getM2()+studBean.getM3())<105)
		    			{
		    		studBean.setGrade("No Grade");
		    		studBean.setResult("FAIL");
		    			}
		    	String d="";
		    	d=cd.addCandidate(studBean);
		    	if(d.equals("SUCCESS"))
		    	{
		    		result=i+":"+studBean.getResult();
		    	}
		    	else
		    	{
		    		result="Error";
		    	}
	    }
		}
	    catch(WrongDataException w)
	    {
	    	result=w.toString();
	    }
	
	    	return result;
		
	}
	public ArrayList<CandidateBean> displayAll(String criteria) throws SQLException,ClassNotFoundException
	{
		ArrayList<CandidateBean> l=null;
	
		if(criteria.equals("PASS") || criteria.equals("FAIL") || criteria.equals("ALL"))
		{
			CandidateDAO cd1=new CandidateDAO();
			l = cd1.getByResult(criteria);
//			System.out.println(l);
		}
		else
		{
			try
			{
				throw new WrongDataException();
			}
			catch(WrongDataException w)
			{
				 
			}
		}
		
		
		return l;
		
	
		
	}
	public static void main(String[] args) throws ClassNotFoundException,SQLException {
		CandidateMain candidateMain = new CandidateMain();

		CandidateBean cb = new CandidateBean();
		cb.setName("AQEEL");
		cb.setM1(90);
		cb.setM2(50);
		cb.setM3(50);
		
		String result = candidateMain.addCandidate(cb);

		System.out.println(result);
	}

}
