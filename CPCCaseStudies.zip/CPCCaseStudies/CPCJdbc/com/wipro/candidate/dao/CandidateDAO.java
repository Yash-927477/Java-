package com.wipro.candidate.dao;
import java.sql.*;
import com.wipro.candidate.util.*;
import com.wipro.candidate.bean.*;
import com.wipro.candidate.util.*;
import java.util.ArrayList;

import com.wipro.candidate.bean.CandidateBean;


public class CandidateDAO {
	
	Connection conn;
	public CandidateDAO() throws ClassNotFoundException,SQLException
	{
		conn=DBUtil.getDBConn();
	}
	
	
	public String addCandidate(CandidateBean studentBean) throws SQLException,ClassNotFoundException
	{
			String status="";
			//Connection conn=DBUtil.getDBConn();
			Statement st =conn.createStatement();
//			String id,name,res,gd;
//			int m1,m2,m3;
//			id=studentBean.
			String sql="insert into candidate_tbl values('"+studentBean.getId()+"','"+studentBean.getName()+"',"+studentBean.getM1()+","+studentBean.getM2()+","+studentBean.getM3()+",'"+studentBean.getResult()+"','"+studentBean.getGrade()+"')";
			int c1=0;
			c1=st.executeUpdate(sql);
			if(c1>0)
				status="SUCCESS";
			else
				status="FAIL";
			return status;
	}
	public ArrayList<CandidateBean> getByResult(String criteria) {
	
		ArrayList<CandidateBean> list=new ArrayList<CandidateBean>();
		String sql = "";
		if(criteria.equals("ALL") || criteria.equals("PASS") || criteria.equals("FAIL"))
		{
		if(criteria.equals("ALL"))
		{
			sql="select * from candidate_tbl";
		}else
		{
			sql="select * from candidate_tbl where result='"+criteria+"'";
		}
		try {
	    Statement st=conn.createStatement();
	    ResultSet rs=st.executeQuery(sql);
	    CandidateBean cb=new CandidateBean();
	    while(rs.next())
	    {
	    	
	    cb.setId(rs.getString(1));
	    cb.setName(rs.getString(2));
	    cb.setM1(rs.getInt(3));
	    cb.setM2(rs.getInt(4));
	    cb.setM3(rs.getInt(5));
	    cb.setResult(rs.getString(6));
	    cb.setGrade(rs.getString(7));
	   list.add(cb);
	    }}
		catch(SQLException s)
		{
			list=null;
		}}
		else
		{
			list=null;
		}
	    
		return list;
	}
	public String generateCandidateId (String name) throws SQLException
	{
		String id="";
		 int a1=0;;
		 id=name.substring(0, 2);
		 id=id.toUpperCase();
		 String sql="select candid_seq.nextval from dual";
		 Statement st=conn.createStatement();
		 ResultSet rs=st.executeQuery(sql);
		 rs.next();
		 
		  a1=rs.getInt(1);
		 
		 id=id+a1;
		return id;
	}
}
