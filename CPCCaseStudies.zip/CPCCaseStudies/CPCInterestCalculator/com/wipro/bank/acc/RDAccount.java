package com.wipro.bank.acc;

public class RDAccount extends Account {
	
	public RDAccount(int tenure, float principal) {
		this.tenure = tenure;
		this.principal = principal;
	}
	
	public float calculateAmountDeposited() {
		return principal*tenure*12;
	}

	
	public float calculateInterest() {
		float cRate,ci=0,r,t,mr;
		float a,b;
		int n=4;
		r=rateOfInterest/100;
		mr=tenure*12;
		while(mr!=0)
		{
		t=mr/12;
		a=1+r/n;
		b=n*t;
		cRate=(float)(Math.pow(a, b)-1);
		ci=ci+(principal*cRate);
		mr--;
		}
		return ci;
	}

	public float calculateMaturityAmount(float totalPrincipalDeposited,
			float maturityInterest){
			return totalPrincipalDeposited + maturityInterest;
	}
	
}
