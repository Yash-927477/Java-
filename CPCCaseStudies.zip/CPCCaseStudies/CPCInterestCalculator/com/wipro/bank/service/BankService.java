package com.wipro.bank.service;
import com.wipro.bank.exception.BankValidationException;
import com.wipro.bank.acc.RDAccount;

public class BankService {
	public String validateData(float principal, int tenure,int age, String gender)
	{
		String status="";
		if(principal==0 || tenure==0 || age==0 || gender.equals(null))
		{
		try
		{
		
			throw new BankValidationException();
		
		}
		catch(BankValidationException e)
		{
			status=e.toString();
		}
		
		
	}
		else
		{
			if(principal<500)
			{
				status="Invalid Principal";
				
			}
			else if(!gender.equalsIgnoreCase("male") && !gender.equalsIgnoreCase("female"))
			{
				status="Invalid Gender";
			}
			else if(tenure!=5 && tenure!=10)
			{
				status="Invalid Tenure";
				return status;
			}
			else if(age>100 || age<1)
			{
				status="Invalid Age";
				return status;
			}
		
	
		}
		if(status.equals(""))
			status="Passed";
		return status;
	}
	public void calculate(float principal, int tenure, int age, String gender)
	{
		String check=validateData(principal,tenure,age,gender);
		if(check.equals("Passed"))
		{
			RDAccount rd=new RDAccount(tenure,principal);
			rd.setInterest(age, gender);
			float x=rd.calculateInterest();
			System.out.println(x);
			float y=rd.calculateAmountDeposited();
			System.out.println(y);
			
			System.out.println(rd.calculateMaturityAmount(x, y));
		}
		
	}
}