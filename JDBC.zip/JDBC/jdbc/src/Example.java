/* practiced how to establish connection and use prepare statement,callable statement */

import java.sql.*;
import java.util.*;
public class Example {
public static void main(String[] args) throws ClassNotFoundException,SQLException
{
	int i=0;
	Scanner sc=new Scanner(System.in);
	Class.forName("oracle.jdbc.OracleDriver");
	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","scott","tiger");
System.out.println("connec succ");
//String sql="insert into demo4 values(seq.nextval,?,?)";
CallableStatement ps=con.prepareCall("{call ret_name(?,?)}");
ps.registerOutParameter(2, Types.VARCHAR);
ps.setInt(1, 101);
ps.execute();
System.out.println(ps.getString(2));
}
}
