import java.sql.*;

public class JDBCCalls {

	public static void main(String[] args) throws ClassNotFoundException,SQLException {
		// TODO Auto-generated method stub
		 

		 Class.forName("oracle.jdbc.OracleDriver");
		 Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:Orcl","scott","tiger");
	    
     int option= Integer.parseInt(args[0]);
     int id= Integer.parseInt(args[1]);
     String name=args[2];
     String date=args[3];
     double marks=Double.parseDouble(args[4]);
     DAOClass d=new DAOClass();
    switch(option)
    	{
    	case 1 : d.insert(id,name,date,marks);
    	           break;
    	case 2 : d.delete(id);
    	break;
    	case 3 : d.modify(id, marks);
    	break;
    	case 4 : d.display();
    	break;
    	}
    }
	}


