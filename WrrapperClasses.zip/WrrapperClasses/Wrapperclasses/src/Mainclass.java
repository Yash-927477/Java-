/* Write a java program that generates the minimum and maximum value for each of the Numeric Wrapper classes (Byte, Short, nteger, Long, Float, Double)

Sample Output:
Integer range: 
min: -2147483648 
max: 2147483647 
Double range: 
min: 4.9E-324 
max: 1.7976931348623157E308 
Long range: 
min: -9223372036854775808 
max: 9223372036854775807 
Short range: 
min: -32768 
max: 32767 
Byte range: 
min: -128 
max: 127 
Float range: 
min: 1.4E-45 
max: 3.4028235E38*/
public class Mainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a,b;
		double c,d;
		long e,f;
		short g,h;
		//Integer i;
		 a=Integer.MAX_VALUE;
		 b=Integer.MIN_VALUE;
		 System.out.println(a+" "+b);
		//Double q;
		c=Double.MAX_VALUE;
		 d= Double.MIN_VALUE;
		 System.out.println(c+" "+d);
		 e=Long.MAX_VALUE;
		 f=Long.MIN_VALUE;
		 System.out.println(e+" "+f);
		 g=Short.MAX_VALUE;
		 h=Short.MIN_VALUE;
		 System.out.println(g+" ");

	}

}
