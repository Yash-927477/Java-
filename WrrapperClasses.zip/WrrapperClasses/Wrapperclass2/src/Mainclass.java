/* Write a program to receive an integer number as a command line argument, and print the binary, octal and hexadecimal equivalent of the given number.

Sample Output:

java  Test 20
Given Number :20
Binary equivalent :10100
Octal equivalent :24
Hexadecimal equivalent :14*/
public class Mainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String a=args[0];
int p=Integer.parseInt(a);
int b,c,f;
 String r=Integer.toBinaryString(p);
 String g=Integer.toHexString(p);
 String h=Integer.toOctalString(p);
 b=Integer.parseInt(r);
 c=Integer.parseInt(g);
 f=Integer.parseInt(h);
 System.out.println(b+" "+c+" "+f);
	}

}
